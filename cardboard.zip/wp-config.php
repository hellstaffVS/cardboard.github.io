<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'cardboard');

/** Имя пользователя MySQL */
define('DB_USER', 'cardboard_admin');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'aDmiN1234');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ne|yPat~us[)?c0?~JO3@!b)<xUoAlt_ G2bdV@CrPX*NS44P-.zIC5A?VHtNtw}');
define('SECURE_AUTH_KEY',  'Cx%7$f=5U{u?f`-X]cPGwgB6BqnLGDev]4~ZrPV*qs*>-^-L(|UbcOn=YM<y_Wne');
define('LOGGED_IN_KEY',    'pL?Et3M-hg}-J`wFUnm47JRomn{+(bL|%5%Q;SzN@2@nKJkwrY/C*ZDb[!j~[|}-');
define('NONCE_KEY',        '0}]_R*E:.Aj=40:iPFivr,5MTI%kHT:_b.K}0o3:stkP3_6Ev}{#Ts&P.U2~LfF7');
define('AUTH_SALT',        'LK0F)&c)B]m&jo|ycqLO2(Ro.I*PD6sEwfmfd`r<YNX*W,<`$@70Q+eGIYXUt2-f');
define('SECURE_AUTH_SALT', 'W{F.|-GxN6A!gq*r>2D #QX4n{z-}}Dt(bPcK!o0[:S-Xz9f}P}baOTsyl!Vc1CE');
define('LOGGED_IN_SALT',   'W=OsI`,>A(Pb8BYU>a=%Zhe%2$(W?V*a0p80U#B#M[o4QDM/A<w$#Z,8d<NPo*UR');
define('NONCE_SALT',       'rJzT]>fy]QWVVikT[jwd+(pr8LES*G:O9iNI,b_f>hqmvp:1iUf0OiB)1~CJ<Z^8');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
